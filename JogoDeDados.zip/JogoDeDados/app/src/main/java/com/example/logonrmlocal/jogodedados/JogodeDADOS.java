package com.example.logonrmlocal.jogodedados;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Random;

public class JogodeDADOS extends AppCompatActivity {

        ImageView imgJogador1;
        ImageView imgJogador2;

        int[] imagens = {
                R.drawable.dado1,
                R.drawable.dado2,
                R.drawable.dado3,
                R.drawable.dado4,
                R.drawable.dado5,
                R.drawable.dado6,
        };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jogode_dados);

        imgJogador1 = findViewById(R.id.imgJogador1);
        imgJogador2 = findViewById(R.id.imgJogador2);
    }

    public void jogar(View view) {
        Random r = new Random();
        int a = r.nextInt(imagens.length);
        int b = r.nextInt(imagens.length);

        imgJogador1.setImageResource(imagens[a]);
        imgJogador2.setImageResource(imagens[b]);

        if(a > b) {
            Toast.makeText(this,"Jogador 1 Ganhou !!!", Toast.LENGTH_SHORT).show();
        }
            else if (b > a) {
            Toast.makeText(this, "Jogador 2 Ganhou !!!", Toast.LENGTH_SHORT).show();
        }
                else {
                    Toast.makeText(this, "Empatou !!!", Toast.LENGTH_SHORT).show();
       }
    }
}
